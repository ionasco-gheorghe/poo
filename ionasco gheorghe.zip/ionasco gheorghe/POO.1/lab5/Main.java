package com.oop.lab5;


public class Main {
    public static void main(String[] args){
        J j = new J("J", new X("J"));
        System.out.println(j);
    }
}
