package com.oop.lab5;

public class X {
    protected String x;

    X(String _x){
        x = _x;
    }

    @Override
    public String toString() {
        return "X{" +
                "x='" + x + '\'' +
                '}';
    }
}
